Bootstrap Material Design theme
Copyright (C) 2014+  Federico Zivolo

This program is free software: you can redistribute it and/or modify
it under the terms you can find below.

You may edit, improve and redistribute this software always under the
terms of this license.

You can use this software for free only for no-profit projects.
If you'd like to use this software in a commercial project you may
contact the author (Federico Zivolo) of the software and ask for his
permission and fulfill his conditions.

You can edit and/or redistribute this software only providing a copy
of this license with it.

You cannot sell this software, any change to the software must be
published under the same license of the original software.

This software may be sold if used inside a software which uses it as
dependency, in any case, this license must be included in the
software. This always after have fulfilled author's conditions.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

This license could be edited in any moment without alert.
